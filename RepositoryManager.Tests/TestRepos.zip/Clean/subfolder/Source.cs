using System;
using System.Linq;
using System.Threading;
using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
[assembly: AssemblyTitle("RandomOutput")]
[assembly: AssemblyVersion("1.0.0.0")]

namespace RandomOutput
{
    internal class Program
    {
        private static void Main(string[] args)
        {
            var useStdout = !args.Contains("noStdout", StringComparer.CurrentCultureIgnoreCase);
            var useStderr = !args.Contains("noStderr", StringComparer.CurrentCultureIgnoreCase);
            var tparam = args.FirstOrDefault(x => x.StartsWith("t")) ?? "t30";
            var seconds = int.Parse(tparam.Substring(1));
            var r = new Random();

            if (useStdout)
                Console.WriteLine("Starting random-output for {0} seconds", seconds);
            if (useStderr)
                Console.Error.WriteLine("Starting random-output on STDERR for {0} seconds", seconds);
            // Run for 30 sek
            var start = DateTime.Now;
            while (DateTime.Now.Subtract(start).TotalSeconds < seconds)
            {
                if (useStdout)
                    for (var i = r.Next(4); i > 0; i--)
                        Console.WriteLine("Some output");
                if (useStderr)
                    for (var i = r.Next(4); i > 0; i--)
                        Console.Error.WriteLine("Bad stuff here");
                Thread.Sleep(2000);
            }
            if (useStdout)
                Console.WriteLine("Leaving random-output");
            if (useStderr)
                Console.Error.WriteLine("Leaving STDERR random-output");
        }
    }
}